package com.example.dogzear;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;


public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    private static final String TAG = "MainActivity";

    private Button profileBtn;
    private Button bookletBtn;
    private Button calendarBtn;
    private Button chartBtn;
    private Button cameraBtn;
    private TextView textViewId;

    String userId;
    String userPwd;

    SharedPreferences userInfo;
    SharedPreferences userInfoDetail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        userInfo = getSharedPreferences("user_info", MODE_PRIVATE);
        userId = userInfo.getString("userId","user");
        userPwd = userInfo.getString("userPwd", "pwd");
//        Intent intent = getIntent();
//        userId = intent.getStringExtra("userId");
//        userPwd = intent.getStringExtra("userPwd");
//        Log.d(TAG, "ID : " + userId +" , PWD : " + userPwd);
        textViewId = findViewById(R.id.tv_id);
        profileBtn = (Button)findViewById(R.id.profile_btn);

        textViewId.setText(userId + " 님");

        profileBtn = (Button) findViewById(R.id.profile_btn);
        bookletBtn = (Button) findViewById(R.id.booklet_btn);
        calendarBtn = (Button) findViewById(R.id.calendar_btn);
        chartBtn = (Button) findViewById(R.id.chart_btn);
        cameraBtn = (Button) findViewById(R.id.camera_btn);

        profileBtn.setOnClickListener(this);
        bookletBtn.setOnClickListener(this);
        calendarBtn.setOnClickListener(this);
        chartBtn.setOnClickListener(this);
        cameraBtn.setOnClickListener(this);

        /*
        하나의 키에 담은 값들을 꺼내온다.

         */
//        userInfoDetail = getSharedPreferences("user_info_detail",MODE_PRIVATE);
//        Set<String> infos = userInfoDetail.getStringSet("infos", null);
//        Log.d(TAG, "값은 총 " + infos.size() + " 개 들어있다. ");
//
//        HashMap<String,String> convertInfos = new HashMap<>();
//
//
//        int i = 0;
//        Iterator<String> iterator = infos.iterator();
//        while(iterator.hasNext()) {
//            String element = iterator.next();
//            String[] splitElement = element.split(":");
//            convertInfos.put(splitElement[0],splitElement[1]);
//            i++;
//            Log.d(TAG, i + " 번재 값 : " + splitElement[0] + " " + splitElement[1]);
//        }
//
//        Log.d(TAG, "hashmap에서 가져온 값   :    " + convertInfos.get("genre"));

    }


    @Override
    public void onClick(View view) {

        if(view == profileBtn) {
            Intent intent = new Intent(this, ProfileActivity.class);
            intent.putExtra("userID", userId);
            intent.putExtra("userPwd", userPwd);
            startActivity(intent);
        }else if(view == bookletBtn) {
            /*책갈피 화면을 클릭하면 라이브러리 화면으로 이동한다.*/
            Intent intent = new Intent(this, LibraryActivity.class);
            intent.putExtra("userID", userId);
            startActivity(intent);
        }else if(view == calendarBtn) {
            Toast.makeText(this, "캘린더를 클릭했습니다.", Toast.LENGTH_SHORT).show();
        }else if(view == chartBtn) {
            Toast.makeText(this, "차트를 클릭했습니다.", Toast.LENGTH_SHORT).show();
        }else if(view == cameraBtn){
            Toast.makeText(this, "메모하기를 클릭했습니다.", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(this, MemoBookActivity.class);
            intent.putExtra("userID", userId);
            intent.putExtra("userPwd", userPwd);
            startActivity(intent);
        }

    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        Log.d(TAG, "액티비티가 다시 시작되면 여기를 거친다." );
    }

    //Activity가 destory 되는 상황을 파악하기 위해
    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        Log.d(TAG, "액티비티가 종료되기 전에 onSaveInstanceState가 실행된다." );
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "OnDestroy가 실행되었다. MainActivity에서" );
    }

    @Override
    public void onBackPressed() {
        /*Back버튼의 기능을 비활성화 시킨다. 로그인 페이지로 돌아가지 못하게 하기 위해.*/
    }
}
