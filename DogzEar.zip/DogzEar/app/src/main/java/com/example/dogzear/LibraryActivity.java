package com.example.dogzear;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.example.dogzear.BookItem;
import com.example.dogzear.ListViewAdapter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;

public class LibraryActivity extends AppCompatActivity implements View.OnClickListener{

    private static final String TAG = "LibraryActivity";
    //SharedPreference의 파일 이름 설정.
    private static final String SETTINGS_BOOK_JSON = "settings_book_json";
    private final int REQUEST_BOOK_CONTENTS = 100;
    private final int REQUEST_MODIFY_CONTENTS = 200;

    private Button addBookBtn;
    private EditText bookSearch;
    private ImageView bookImage;
    private TextView tv_title;
    private TextView tv_author;
    private TextView tv_date;

    ListView listview;
    ListViewAdapter adapter;
    BookItem item;
    ArrayList<BookItem> listViewItemList;

    String bookTitle = "";
    String bookAuthor = "";
    String bookDate = "";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_library);

        listViewItemList = getStringArrayPref(getApplicationContext(), SETTINGS_BOOK_JSON);

        //Adapter 생성
        adapter = new ListViewAdapter(listViewItemList);

        listview = (ListView) findViewById(R.id.book_list);
        listview.setAdapter(adapter);

        // 첫 번째 아이템 추가.  --> 세부정보에 사진이 안나오는 문제 해결할 것 (이미지를 직접 drawable파일에 넣을것.)
//        Bitmap bitmap = ((BitmapDrawable)ContextCompat.getDrawable(this, R.drawable.book_logo)).getBitmap();

        SharedPreferences pref = getSharedPreferences("user_info", MODE_PRIVATE);
        boolean inputItems = pref.getBoolean("isInputBook", false);
        if(!inputItems) {
            adapter.addItem(((BitmapDrawable) ContextCompat.getDrawable(this, R.drawable.book_item_sample1)).getBitmap(),
                    "켄트 벡의 구현패턴", "켄트 백", "20/09/08");

            // 두 번째 아이템 추가.
            adapter.addItem(((BitmapDrawable) ContextCompat.getDrawable(this, R.drawable.book_item_sample2)).getBitmap(),
                    "무지한 스승", "자크 랑시에르", "20/09/10");

            // 세번째 아이템 추가.
            adapter.addItem(((BitmapDrawable) ContextCompat.getDrawable(this, R.drawable.book_item_sample3)).getBitmap(),
                    "카스테라", "박민규", "20/09/10");
            inputItems = true;
            SharedPreferences.Editor editor = pref.edit();
            editor.putBoolean("isInputBook", inputItems);
            editor.apply();
        }

        addBookBtn = (Button) findViewById(R.id.add_book_btn);
        bookImage = (ImageView) findViewById(R.id.book_image);
        tv_title = (TextView) findViewById(R.id.book_title);
        tv_author = (TextView) findViewById(R.id.book_author);
        tv_date = (TextView) findViewById(R.id.book_date);

        addBookBtn.setOnClickListener(this);

        //위에서 생성한 listview에 클릭 이벤트 핸들러 정의.
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                ByteArrayOutputStream stream = new ByteArrayOutputStream();

                Toast.makeText(getApplicationContext(),  (position + 1) + " 번째 아이템을 터치하였습니다.", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getApplicationContext(), BookInfoActivity.class);
                /*수정해야 할 인덱스를 담는다.*/
                item = adapter.getItem(position);
                int pos = position;
                Bitmap image = item.getImage();
                image.compress(Bitmap.CompressFormat.JPEG, 100, stream);
                byte[] byteArray = stream.toByteArray();
                String title = item.getTitle();
                String author = item.getAuthor();
                String date = item.getDate();

                intent.putExtra("image", byteArray);
                intent.putExtra("title", title);
                intent.putExtra("author", author);
                intent.putExtra("date", date);
                intent.putExtra("position", pos);

                startActivityForResult(intent,REQUEST_MODIFY_CONTENTS);

            }
        });


    }

    /*임시저장할 값이 없을때, 저장완료나 취소시 초기화 해준다.*/
    //Intent tempData = null;


    @Override
    public void onClick(View view) {
        if(view == addBookBtn) {
            //수정하고 난 후의 결과값을 초기화 한다.
//            bookTitle = "";
//            bookAuthor = "";
//            bookDate = "";
            Intent intent = new Intent(this, AddBookActivity.class);

            Toast.makeText(getApplicationContext(), "입력할 bookTitle :  " + bookTitle, Toast.LENGTH_SHORT).show();
            Log.d(TAG, "입력할 bookTitle. : " + bookTitle + ", bookAuthor : " + bookAuthor + ", bookDate : " + bookDate);
            startActivityForResult(intent,REQUEST_BOOK_CONTENTS);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
//        Log.d(TAG, "onActivityResult결과를 받아온다. : " + data.getStringExtra("back_button"));
        bookTitle = "";
        bookAuthor = "";
        bookDate = "";

        if (requestCode == REQUEST_BOOK_CONTENTS && resultCode == RESULT_OK) {

            /*등록버튼의 결과*/
            if(data.getStringExtra("RESULT").toString().equals("add")) {

                bookTitle = data.getStringExtra("title").toString();
                bookAuthor = data.getStringExtra("author").toString();
                bookDate = data.getStringExtra("date").toString();

                String result = data.getStringExtra("RESULT");
                Log.d(TAG, "등록 버튼을 누르고 이곳으로 들어왔다.");

                //사진을 등록하지 않을시 기본 이미지로 대체한다.
                Bitmap bitmap = ((BitmapDrawable)ContextCompat.getDrawable(this, R.drawable.book_logo)).getBitmap();

                if(data.hasExtra("image")) {
                    byte[] byteArray = data.getByteArrayExtra("image");

                    bitmap = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
                    //bookImage.setImageBitmap(bitmap);
                }

                Toast.makeText(getApplicationContext(), "result : " + result, Toast.LENGTH_SHORT).show();
                /*등록시켜줘야 할 부분*/

//                    tv_title.setText(bookTitle);
//                    tv_author.setText(bookAuthor);
//                    tv_date.setText(bookDate);

                adapter.addItem(bitmap, bookTitle, bookAuthor, bookDate) ;
                //Listview 갱신
                adapter.notifyDataSetChanged();

                /*취소버튼의 결과*/
            } else if (data.getStringExtra("RESULT").toString().equals("CANCEL")) {
                String result = data.getStringExtra("RESULT");
                Log.d(TAG, "취소 버튼을 누르고 이곳으로 들어왔다.");
                Toast.makeText(getApplicationContext(), "result : "  + result, Toast.LENGTH_SHORT).show();

            }
            /*취소하거나 등록을 하면 bookTitle을 초기화 시켜줘야 한다.*/
            bookTitle = "";
            bookAuthor = "";
            bookDate = "";
            //}
        } else if(requestCode == REQUEST_MODIFY_CONTENTS && resultCode == RESULT_OK) {
            int position = data.getIntExtra("position", -1);
            Log.d(TAG, "삭제할 인덱스값 : " + position + "========================================DELETE");
            if(data.getStringExtra("RESULT").toString().equals("DELETE")) {
                adapter.removeItem(position);
                //Listview 갱신
                adapter.notifyDataSetChanged();
            } else if(data.getStringExtra("RESULT").toString().equals("MODIFY")) {
                item = adapter.getItem(position);
               /*
                String bookTitle = "";
                String bookAuthor = "";
                String bookDate = "";
                */
                bookTitle = data.getStringExtra("title");
                bookAuthor = data.getStringExtra("author");
                bookDate = data.getStringExtra("date");
                item.setTitle(bookTitle);
                item.setAuthor(bookAuthor);
                item.setDate(bookDate);
                adapter.notifyDataSetChanged();
            }

        }
    }

    @Override
    protected void onPause() {
        super.onPause();

        setStringArrayPref(SETTINGS_BOOK_JSON, listViewItemList);
        Log.d(TAG, "Put json");
    }

    private void setStringArrayPref(String key, ArrayList<BookItem> items) {

        SharedPreferences prefs = getSharedPreferences(SETTINGS_BOOK_JSON, MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        JSONArray jsonBookArray = new JSONArray();
        JSONObject jsonBookObject;
        /*
         private Bitmap image;
         private String title;
         private String author;
         private String date;
         */
        for(int i = 0; i < items.size(); i++) {
            jsonBookObject = new JSONObject();
            try {
                jsonBookObject.put("image", BitMapToString(items.get(i).getImage()));
                jsonBookObject.put("title", items.get(i).getTitle());
                jsonBookObject.put("author", items.get(i).getAuthor());
                jsonBookObject.put("date", items.get(i).getDate());
                jsonBookArray.put(jsonBookObject);
            }catch (JSONException e) {
                e.printStackTrace();
            }

            if(!items.isEmpty()) {
                editor.putString(key, jsonBookArray.toString());
            }

            editor.apply();
        }
    }

    private ArrayList<BookItem> getStringArrayPref(Context context, String key) {

        SharedPreferences pref = getSharedPreferences(SETTINGS_BOOK_JSON, MODE_PRIVATE);
        String jsonBookStr = pref.getString(key, null);
        ArrayList<BookItem> items = new ArrayList<BookItem>();
        BookItem item;

        if(jsonBookStr != null) {
            try {
                JSONArray jsonBookArray = new JSONArray(jsonBookStr);
                JSONObject jsonBookObject;

                for(int i = 0; i < jsonBookArray.length(); i++) {
                    jsonBookObject = new JSONObject();

                    jsonBookObject = jsonBookArray.getJSONObject(i);
                    Bitmap image = StringToBitMap(jsonBookObject.optString("image"));
                    String title = jsonBookObject.optString("title");
                    String author = jsonBookObject.optString("author");
                    String date = jsonBookObject.optString("date");
                    item = new BookItem();
                    item.setImage(image);
                    item.setTitle(title);
                    item.setAuthor(author);
                    item.setDate(date);

                    items.add(item);
                }
            }catch (JSONException e) {
                e.printStackTrace();
            }

        }
        return items;
    }



    //비트맵을 String 으로 변환하는 메소드
    public String BitMapToString(Bitmap bitmap) {
        ByteArrayOutputStream baos=new  ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG,100, baos);
        byte [] b=baos.toByteArray();
        String temp= Base64.encodeToString(b, Base64.DEFAULT);

        return temp;
    }

    //encoding된 String 을 Bitmap으로 변환하는 메소드
    public Bitmap StringToBitMap(String encodedString) {
        try {
            byte [] encodeByte=Base64.decode(encodedString,Base64.DEFAULT);
            Bitmap bitmap= BitmapFactory.decodeByteArray(encodeByte, 0, encodeByte.length);
            return bitmap;
        } catch(Exception e) {
            e.getMessage();
            return null;
        }
    }

}




























