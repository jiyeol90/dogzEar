package com.example.dogzear;

import android.Manifest;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.drawable.BitmapDrawable;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import com.gun0912.tedpermission.PermissionListener;
import com.gun0912.tedpermission.TedPermission;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class AddBookActivity extends AppCompatActivity implements View.OnClickListener{

    private static final String TAG = "AddBookActivity";
    private final int GET_GALLERY_IMAGE = 200;
    private final int REQUEST_IMAGE_CAPTURE = 300;
    private String imageFilePath;
    private Uri photoUri;
    private final String BOOK_TITLE = "BOOK_TITLE";
    /*카메라 앱으로 사진을 찍었을 경우 true */
    private boolean isCaptured = false;
    /*갤러리에서 가져와 나타낼 이미지의 크기*/
    int reqHeight;
    int reqWidth;

    ImageView bookImage;
    Button galleryImageBtn;
    Button cameraBtn;
    Button cancelBtn;
    Button bookUpdateBtn;

    EditText bookTitle;
    EditText bookAuthor;
    EditText bookDate;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_book);

        TedPermission.with(getApplicationContext())
                .setPermissionListener(permissionListener)
                .setRationaleMessage("카메라 권한이 필요합니다.")
                .setDeniedMessage("거부하셨습니다.")
                .setPermissions(Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.CAMERA)
                .check();

        bookImage = (ImageView) findViewById(R.id.search_bar);
        cameraBtn = (Button) findViewById(R.id.camera_btn);
        cancelBtn = (Button) findViewById(R.id.cancel_btn);
        bookUpdateBtn = (Button) findViewById(R.id.book_update_btn);
        galleryImageBtn = (Button) findViewById(R.id.gallery_image_btn);
        bookTitle = (EditText) findViewById(R.id.et_title);
        bookAuthor = (EditText) findViewById(R.id.et_author);
        bookDate = (EditText) findViewById(R.id.et_date);

        bookImage.setOnClickListener(this);
        cameraBtn.setOnClickListener(this);
        galleryImageBtn.setOnClickListener(this);
        cancelBtn.setOnClickListener(this);
        bookUpdateBtn.setOnClickListener(this);
        bookDate.setOnClickListener(this);


        /*임시저장 값들(제목, 작가, 날짜)을 뿌려준다*/
        Intent intent = getIntent();
        String getTitle = intent.getStringExtra("bookTitle");
        Log.d(TAG, "bookTitle : " + getTitle);
        bookTitle.setText(getTitle);
        String getAuthor = intent.getStringExtra("bookAuthor");
        bookAuthor.setText(getAuthor);
        String getBookDate = intent.getStringExtra("bookDate");
        bookDate.setText(getBookDate);


    }

    @Override
    public void onClick(View view) {
        /*카메라 앱의 액티비티 호출*/
        if (view == cameraBtn) {
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            if (intent.resolveActivity(getPackageManager()) != null) {
                File photoFile = null;
                try {
                    photoFile = createImageFile();
                } catch (IOException e) {

                }
                if (photoFile != null) {
                    photoUri = FileProvider.getUriForFile(getApplicationContext(), getPackageName(), photoFile);
                    intent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri);
                    startActivityForResult(intent, REQUEST_IMAGE_CAPTURE);
                }
            }
            /*갤러리에서 이미지 가져오기*/
        } else if (view == galleryImageBtn) {
            Intent intent = new Intent(Intent.ACTION_PICK);
            intent.setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image/*");
            startActivityForResult(intent, GET_GALLERY_IMAGE);

        } else if (view == cancelBtn) {
            Log.d(TAG, "취소버튼을 누르면 바로 취소");
            Intent intent = new Intent();
            intent.putExtra("RESULT", "CANCEL");
            setResult(RESULT_OK, intent);
            finish();
        } else if (view == bookUpdateBtn) {
            Log.d(TAG, "등록 버튼을 눌렀다. ==================================bookUpdateBtn");
            Intent intent = new Intent();
            intent.putExtra("RESULT", "add");
            /*저장할 데이터를 담는다.*/
            //bookImage = (ImageView) findViewById(R.id.book_image);
            //bookTitle = (EditText) findViewById(R.id.et_title);
            //bookAuthor = (EditText) findViewById(R.id.et_author);
            //bookDate = (EditText) findViewById(R.id.et_date);
            String title = bookTitle.getText().toString();
            String author = bookAuthor.getText().toString();
            String date = bookDate.getText().toString();
            //BitmapDrawable drawable = (BitmapDrawable)bookImage.getDrawable();
            //Bitmap bitmap = drawable.getBitmap();
            //Drawable bookCover = bookImage.getDrawable();

                if(isCaptured) {
                    ByteArrayOutputStream stream = new ByteArrayOutputStream();
                    Bitmap bitmap = ((BitmapDrawable) bookImage.getDrawable()).getBitmap();
//                BitmapDrawable drawable = (BitmapDrawable)bookImage.getDrawable();
//                Bitmap bitmap = drawable.getBitmap();
                    System.out.println("bitmap.getByteCount() : " + bitmap.getByteCount() + " 을 저장합니다");
                    Log.d(TAG, "bitmap.getByteCount() : " + bitmap.getByteCount() + " 을 저장합니다");
//            float scale = (float) (1024/(float)bitmap.getWidth());
//            int image_w = (int) (bitmap.getWidth() * scale);
//            int image_h = (int) (bitmap.getHeight() * scale);
//            Bitmap resize = Bitmap.createScaledBitmap(bitmap, image_w, image_h, true);
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 100, stream);
                    byte[] byteArray = stream.toByteArray();
                    intent.putExtra("image", byteArray);
                }


            intent.putExtra("title", title);
            intent.putExtra("author", author);
            intent.putExtra("date", date);

            //intent.putExtra("image", bitmap);
            setResult(RESULT_OK, intent);
            finish();
        }

    }

//    private boolean hasImage(@NonNull ImageView view) {
//        Drawable drawable = view.getDrawable();
//        boolean hasImage = (drawable != null);
//
//        if (hasImage && (drawable instanceof BitmapDrawable)) {
//            hasImage = ((BitmapDrawable)drawable).getBitmap() != null;
//        }
//
//        return hasImage;
//    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        /*카메라 앱의 결과*/
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            isCaptured = true;
            BitmapFactory.Options imgOptions = new BitmapFactory.Options();
            /*options.inJustDecodeBounds를 true로 설정하면 이미지를 decodeing할때 이미지의 크기만을 먼저 불러와
             *OutofMemory Exception을 일으킬만한 큰 이미지를 불러오더라도 선처리를 가능하도록 해준다.
             */
            //imgOptions.inJustDecodeBounds = true;
            imgOptions.inSampleSize = 10;
            Bitmap bitmap = BitmapFactory.decodeFile(imageFilePath, imgOptions);
            ExifInterface exif = null;

            try {
                exif = new ExifInterface(imageFilePath);
            } catch (IOException e) {
                e.printStackTrace();
            }

            int exifOrientation;
            int exifDegree;

            if (exif != null) {
                exifOrientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
                exifDegree = exifOrientationToDegrees(exifOrientation);
            } else {
                exifDegree = 0;
            }

            // 이미지 뷰에 비트맵을 set하여 이미지 표현
            bookImage.setImageBitmap(rotate(bitmap, exifDegree));
            /*갤러리 앱의 결과*/
        } else if (requestCode == GET_GALLERY_IMAGE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            isCaptured = true;
//            BitmapFactory.Options imgOptions = new BitmapFactory.Options();
//            imgOptions.inJustDecodeBounds = true;
            //imgOptions.inSampleSize = 10;
//            Uri selectedImageUri = data.getData();
//            bookImage.setImageURI(selectedImageUri);
            Matrix matrix = new Matrix();
            matrix.postRotate(90);
            try {
                InputStream in = getContentResolver().openInputStream(data.getData());
                Bitmap img = BitmapFactory.decodeStream(in);
                Bitmap resized = Bitmap.createScaledBitmap(img, 200, 250, true);

                in.close();
                bookImage.setImageBitmap(resized);

            }catch (Exception e) {
                e.printStackTrace();

//                BitmapFactory.Options imgOptions = new BitmapFactory.Options();
//                /*options.inJustDecodeBounds를 true로 설정하면 이미지를 decodeing할때 이미지의 크기만을 먼저 불러와
//                 *OutofMemory Exception을 일으킬만한 큰 이미지를 불러오더라도 선처리를 가능하도록 해준다.
//                 */
//                //imgOptions.inJustDecodeBounds = true;
//                imgOptions.inSampleSize = 10;
//                Bitmap bitmap = BitmapFactory.decodeFile(imageFilePath, imgOptions);
            }
//            final int height = imgOptions.outHeight;
//            final int width = imgOptions.outWidth;
//            reqHeight = 150;
//            reqWidth = 150;
//            int inSampleSize = 1;
//            if(height < reqHeight || width > reqWidth) {
//                final int heightRatio = Math.round((float) height / (float) reqHeight);
//                final int widthRatio = Math.round((float) height / (float) reqWidth);
//                inSampleSize = heightRatio < widthRatio ? heightRatio : widthRatio;
//            }


        }
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
            EditText bookTitle = findViewById(R.id.et_title);
            String title = bookTitle.getText().toString();
            outState.putCharSequence(BOOK_TITLE, title);
            Log.d(TAG, "종료전에 제목: " + title +" 을 저장합니다");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG, "AddBook액티비티가 일시정지됩니다. onPause()");
        /*back버튼을 눌렀는지 확인*/
//        if(isClicked) {
//            EditText bookTitle = findViewById(R.id.et_title);
//            String title = bookTitle.getText().toString();
//
//            Intent intent = new Intent();
//            intent.putExtra("back_button", "백버튼 눌렀다.");
//            if (title.length() != 0) {
//                intent.putExtra("title", title);
//                Log.d(TAG, "AddBook액티비티가 BACKBUTTON을 눌러일지정지되었고  BOOK_TITLE 은 " + title + " 입니다.");
//            } else {
//                Log.d(TAG, "AddBook액티비티가 BACKBUTTON을 눌러일지정지되었고 제목은 없다. onPause()");
//            }
//            setResult(RESULT_OK, intent);
//            finish();
//        } else {
//            Log.d(TAG, "AddBook액티비티가 일지정지됩니다. onPause()");
//        }
//////////////////////////////////////////////////////////////////////////

    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d(TAG, "AddBook액티비티가 정지됩니다. onStop()");
    }

    /*BackButton을 누를시*/
    @Override
    public void onBackPressed() {
        //부모클래스에서 백버튼 처리를 하기 전에 처리해줄 것들
        //isClicked = true;
//        Log.d(TAG, "백버튼을 눌렀다. onBackPressed() , isClicked : ");
//            EditText bookTitle = findViewById(R.id.et_title);
//            String title = bookTitle.getText().toString();
//            String author = bookAuthor.getText().toString();
//            String date = bookDate.getText().toString();
//
//            if(title.length() == 0) title = "";
//            if(author.length() == 0) author = "";
//            if(date.length() == 0) date = "";
//
//            Intent intent = new Intent();
//            intent.putExtra("back_button", true);
//
//            intent.putExtra("title", title);
//            intent.putExtra("author", author);
//            intent.putExtra("date", date);
//            Log.d(TAG, "AddBook액티비티가 BACKBUTTON을 눌러일지정지되었고  BOOK_TITLE 은 " + title + " 입니다.");
//
//            setResult(RESULT_OK, intent);
//            finish();
            super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "AddBook액티비티가 소멸됩니다. onDestroy()");
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        EditText bookTitle = findViewById(R.id.et_title);
        CharSequence title = savedInstanceState.getCharSequence(BOOK_TITLE);
        bookTitle.setText(title);
        Log.d(TAG, "다시시작할때 제목: " + title + "을 저장합니다");
    }

    PermissionListener permissionListener = new PermissionListener() {
        @Override
        public void onPermissionGranted() {
            Toast.makeText(getApplicationContext(), "권한이 허용됨",Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onPermissionDenied(ArrayList<String> deniedPermissions) {
            Toast.makeText(getApplicationContext(), "권한이 거부됨",Toast.LENGTH_SHORT).show();
        }
    };

    private File createImageFile() throws IOException {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "TEST_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(
                imageFileName,
                ".jpg",
                storageDir
        );
        imageFilePath = image.getAbsolutePath();
        return image;
    }

    /*사진의 각도를 계산하여 바르게 맞춰준다.*/
    private int exifOrientationToDegrees(int exifOrientation) {
        if (exifOrientation == ExifInterface.ORIENTATION_ROTATE_90) {
            return 90;
        } else if (exifOrientation == ExifInterface.ORIENTATION_ROTATE_180) {
            return 180;
        } else if (exifOrientation == ExifInterface.ORIENTATION_ROTATE_270) {
            return 270;
        }
        return 0;
    }

    private Bitmap rotate(Bitmap bitmap, float degree) {
        Matrix matrix = new Matrix();
        matrix.postRotate(degree);
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
    }

}
