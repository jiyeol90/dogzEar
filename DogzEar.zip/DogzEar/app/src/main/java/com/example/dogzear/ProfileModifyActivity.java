package com.example.dogzear;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class ProfileModifyActivity extends AppCompatActivity {

    private static final String TAG = "ProfileModifyActivity";

    SharedPreferences userInfoDetail;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_modify);


        userInfoDetail = getSharedPreferences("user_info_detail",MODE_PRIVATE);
        Set<String> infos = userInfoDetail.getStringSet("infos", null);
        Log.d(TAG, "값은 총 " + infos.size() + " 개 들어있다. ");

        HashMap<String,String> convertInfos = new HashMap<>();


        int i = 0;
        Iterator<String> iterator = infos.iterator();
        while(iterator.hasNext()) {
            String element = iterator.next();
            String[] splitElement = element.split(":");
            convertInfos.put(splitElement[0],splitElement[1]);
            i++;
            Log.d(TAG, i + " 번재 값 : " + splitElement[0] + " " + splitElement[1]);
        }

        Log.d(TAG, "hashmap에서 가져온 값   :    " + convertInfos.get("genre"));

    }
}
