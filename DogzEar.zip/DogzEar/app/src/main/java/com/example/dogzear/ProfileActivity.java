package com.example.dogzear;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class ProfileActivity extends AppCompatActivity implements View.OnClickListener {

    private TextView tv_logout;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        tv_logout = (TextView)findViewById(R.id.logout);

        tv_logout.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if(view == tv_logout) {
            Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
            /*기존의 아이디 화면을 출력할때 onCreate()로 생성하지않고 onNewIntent()를 거쳐 뿌려주자.
             액티비티 생성도 객체의 생성이므로 자원낭비에 유의할 것.*/
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        }
    }
}
