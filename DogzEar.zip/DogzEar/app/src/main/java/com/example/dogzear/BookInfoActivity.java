package com.example.dogzear;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.io.ByteArrayOutputStream;

public class BookInfoActivity extends AppCompatActivity implements View.OnClickListener{


    ImageView bookImage;
    Button deleteBtn;
    Button bookModifyBtn;

    EditText bookTitle;
    EditText bookAuthor;
    EditText bookDate;

    //리스트 아이템의 인덱스 (수정, 삭제할 경우 인덱스 정보를 이용한다.)
    int position;

    String title;
    String author;
    String date;
    Bitmap image;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_info);

        bookImage = (ImageView) findViewById(R.id.search_bar);
        deleteBtn = (Button) findViewById(R.id.delete_btn);
        bookModifyBtn = (Button) findViewById(R.id.book_modify_btn);
        bookTitle = (EditText) findViewById(R.id.et_title);
        bookAuthor = (EditText) findViewById(R.id.et_author);
        bookDate = (EditText) findViewById(R.id.et_date);


        deleteBtn.setOnClickListener(this);
        bookModifyBtn.setOnClickListener(this);
        bookDate.setOnClickListener(this);

        Intent intent = getIntent();

        byte[] byteArray = intent.getByteArrayExtra("image");

        image = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
        //Bitmap getImage = intent.getParcelableExtra("image");
        bookImage.setImageBitmap(image);
        title = intent.getStringExtra("title");
        bookTitle.setText(title);
        author = intent.getStringExtra("author");
        bookAuthor.setText(author);
        date = intent.getStringExtra("date");
        bookDate.setText(date);
        position = intent.getIntExtra("position", -1);

        Toast.makeText(this, "내가 택한 아이템은 " + (position+1)  + "번째 아아템이다. ", Toast.LENGTH_SHORT).show();


    }

    @Override
    public void onClick(View view) {
        Intent resultIntent = new Intent();
        /*수정하기 버튼을 누를시 정보를 보낸다.*/
        if(view == bookModifyBtn) {

            //나중에 사진도 수정할 수 있는기능 추가할 것
            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            image.compress(Bitmap.CompressFormat.JPEG, 100, stream);
            image = ((BitmapDrawable)bookImage.getDrawable()).getBitmap();
            byte[] byteArray = stream.toByteArray();
            title = bookTitle.getText().toString();
            author = bookAuthor.getText().toString();
            date = bookDate.getText().toString();

            resultIntent.putExtra("image", byteArray);
            resultIntent.putExtra("title", title);
            resultIntent.putExtra("author", author);
            resultIntent.putExtra("date", date);
            resultIntent.putExtra("RESULT", "MODIFY");
            resultIntent.putExtra("position", position);
            setResult(RESULT_OK, resultIntent);
            finish();
        }else if(view == deleteBtn) {

            resultIntent.putExtra("RESULT", "DELETE");
            resultIntent.putExtra("position", position);
            setResult(RESULT_OK, resultIntent);
            finish();
        }

    }
}

























